﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VietTravel.ZaloPay.Response
{
    public class CreateZalopayPayResponse
    {
    }
}